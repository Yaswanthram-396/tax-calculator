while True:
    try:
        print("Enter only positive Integers")
        income = int(input("Please enter your taxable income in India: "))
    except ValueError:
        print("Sorry, We didn't understand that please enter taxable income as a number")
        continue
    else:
       break
tax_income=income-50000
# Here 50000 is deducted from income because discount given by govt.
if income<=250000:
    print("No tax")
#there is no tax untill 250000
if (income>250000) and (income<=500000):
    print (int((tax_income-250000)*5/100))
#there is a 5% tax over the amount 250000 to 500000
if (income>500000) and (income<=750000):
    print(int(((tax_income-500000)*10/100)+((250000)*(5/100))))
#there is a 10% tax over 500000 to 750000 and 500000 subtracted from tax_income
# because 250000 is the taxable amount and second 5% of 250000 is added.
if(income>750000)and(income<=1000000):
    print(((tax_income-750000)*15/100)+((250000)*10/100)+((250000)*(5/100)))
#there is a 15% tax over 750000 to 1000000 and 750000 subtracted from tax_income
# because 250000 is the taxable amount , third 10% of 250000 is added,second 5% of 250000 is added. 
if (income>1000000)and (income<=1250000):
     print(int(((tax_income-1000000)*20/100)+(((250000)*15/100)+((250000)*10/100)+((250000)*(5/100)))))
#there is a 20% tax over 1000000 to 1250000 and 1000000 subtracted from tax_income
# because 250000 is the taxable amount ,fourth 15% of 250000 is added, third 10% of 250000 is added,and second 5% of 250000 is added. 
if (income>1250000)and (income<=1500000):
    print(int(((tax_income-1250000)*25/100)+(((250000)*20/100)+((250000)*15/100)+((250000)*10/100)+((250000)*(5/100)))))
#there is a 25% tax over 1250000 to 1500000 and 1250000 subtracted from tax_income
# because 250000 is the taxable amount,fifth 20% of 250000 is added ,fourth 15% of 250000 is added, third 10% of 250000 is addthird 15% of 250000 is addeded,
#and second 5% of 250000 is added
if income>1500000:
    print(int(((tax_income-1500000)*30/100)+(((250000)*25/100)+((250000)*20/100)+((250000)*15/100)+((250000)*10/100)+((250000)*(5/100)))))
#there is a 30% tax over 1500000 and 1500000 subtracted from tax_income
# because 250000 is the taxable amount,sixth 25% of 250000 is added,fifth 20% of 250000 is added ,fourth 15% of 250000 is added, third 10% of 250000 is addthird 15% of 250000 is addeded,
#and second 5% of 250000 is added